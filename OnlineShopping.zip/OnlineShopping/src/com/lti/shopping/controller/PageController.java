package com.lti.shopping.controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


import com.lti.shopping.model.OrderDetail;

import com.lti.shopping.model.Product;
import com.lti.shopping.model.Seller;

import com.lti.shopping.model.UserDetails;

import com.lti.shopping.service.ProductService;
import com.lti.shopping.service.SellerService;
import com.lti.shopping.service.UserService;


@Controller
@SessionAttributes("seller")
public class PageController {

	private UserService userService;

	private SellerService sellerService;

	private ProductService productService;


	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	@Autowired
	public void setSellerService(SellerService sellerService) {
		this.sellerService = sellerService;
	}

	@Autowired
	public void setUserService(UserService ps) {
		this.userService = ps;
	}

	

	
	   @RequestMapping(value = { "/" ,"/index"}) 
	public ModelAndView goHome() { 
	  ModelAndView mv = new ModelAndView("index.jsp");
	  return mv; 
	  }
	 
	@RequestMapping(value = "/home")
	public String home(HttpSession session) {
		
	   return "redirect:/";
	}

	 

	
	// for user

	
	
	  @RequestMapping(value = "/login") public String login(Model model) {
	  model.addAttribute("userdetails",new UserDetails()); return "login"; }
	 

	@RequestMapping(value = "/addToCart")
	public String toCart(Model model ,HttpSession session,@ModelAttribute("order") OrderDetail order) {
		 System.out.println("hello to cart ");
		 if(session.getAttribute("email")==null) {
			 System.out.println("hello");
			 model.addAttribute("userdetails",new UserDetails());
		return "login";
		 }
		 else
			 System.out.println("hello mayuriS");
			 System.out.println("I am in Prod.........."+order);
			 session.setAttribute("productName",order.getProductName());
		 session.setAttribute("pdescription",order.getPdescription());
		 session.setAttribute("quantity",order.getQuantity());
		 session.setAttribute("price",order.getPrice());
		 session.setAttribute("grandTotal",order.getGrandTotal());
			
			 return "cart";
	}
	
	@RequestMapping(value = "/addToCard")
	public String card(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "pay";
	}
	
	@RequestMapping(value = "/image1")
	public String image1(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "img1";
	}
	@RequestMapping(value = "/image2")
	public String image2(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "img2";
	}
	@RequestMapping(value = "/image3")
	public String image3(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "img3";
	}
	@RequestMapping(value = "/image4")
	public String image4(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "img4";
	}
	@RequestMapping(value = "/image5")
	public String image5(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "img5";
	}
	@RequestMapping(value = "/image6")
	public String image6(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "img6";
	}
	@RequestMapping(value = "/image7")
	public String image7(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "img7";
	}
	@RequestMapping(value = "/image8")
	public String image8(Model m) {
		m.addAttribute("order", new OrderDetail());
	   return "img8";
	}
	
	@RequestMapping(value = "/loginverification", method = RequestMethod.POST)
	public String LoginValidation(@ModelAttribute ("userdetails")
									@Valid UserDetails u, 
									BindingResult result, HttpServletRequest req, HttpSession session,Model model) {
		String email = req.getParameter("email");
		String password = req.getParameter("password");

	 

		if (email.equals("admin@gmail.com") && password.equals("admin"))

		{
			return "admin";

		} else if (userService.verifyUser(email, password)) {
			System.out.println("in control");
			
			session.setAttribute("email",u.getEmail());
		
			System.out.println("after control");
			return "redirect:/";
		} else
			
			return "login";

	}

	@RequestMapping(value = "/register")
	public String register(Model m) {
		m.addAttribute("user", new UserDetails());
		return "register";
	}

	@RequestMapping(value = "/register/add", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("user") UserDetails u, BindingResult result, Model model, HttpSession session) {
		try {
			if (!result.hasErrors()) {
				if (u.getId() == null || u.getId() == 0) {

					this.userService.addUser(u);
					
				}
				session.setAttribute("address",u.getAddress());
				session.setAttribute("fullname",u.getFirstName()+""+u.getLastName());
				return "redirect:/login";
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return "register";
	}

	// for seller

	@RequestMapping(value = "/seller_login")
	public ModelAndView sellerLogin() {
		ModelAndView mv = new ModelAndView("seller_login");
		return mv;
	}

	@RequestMapping(value = "/seller_register")
	public String registerSeller(Model m) {

		m.addAttribute("seller", new Seller());
		return "seller_register";
	}

	@RequestMapping(value = "/selleradd", method = RequestMethod.POST)
	public String addSeller(@ModelAttribute("seller") Seller s, BindingResult result, Model model) {

		try {
			if (!result.hasErrors()) {
				if (s.getSellId() == null || s.getSellId() == 0) {

					this.sellerService.addSeller(s);
				}

				return "seller_login";
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return "seller_register";
	}
	
	


	
	@RequestMapping(value = "/sellerverification", method = RequestMethod.POST)
	public String SellerValidation(Model model, HttpServletRequest req, HttpSession session ) {
		String email = req.getParameter("email");
		String password = req.getParameter("password");



		if (sellerService.verifySeller(email, password)) {
			
			
		
			 Seller sellerobj = sellerService.getByEmail(email);
		
			 System.out.println("hello mayuri ");
			 session.setAttribute("seller",sellerobj);
			 
			 
			
			
			model.addAttribute("product", new Product());
			System.out.println("product model object created .. and sent to view");
			
			return "sellerdashboard1";//seller ka jsp
		} else
			return "seller_login";

	}

	// for product

	@RequestMapping(value = "/productadd", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product p, BindingResult result, Model model, HttpSession ses,Seller seller) {

     Seller s=(Seller)ses.getAttribute("seller");
		p.setSeller(s);
		this.productService.add(p);
		System.out.println("prod added");
		return "sellerdashboard1";

	}

	@RequestMapping(value = "/thanks")
	public String thanks(HttpSession session) {
		
	   return "logout";
	}
	
	

	@RequestMapping(value = "/logout")
	public String logout(HttpSession session) {
		session.invalidate();
	   return "redirect:/";
	}
	
	@RequestMapping(value = "/listProducts", method = RequestMethod.GET)
	public String listProducts(Model model,HttpSession ses) {
		model.addAttribute("product", new Product());// model
		model.addAttribute("listProducts", 
				this.productService.listProducts());
		return "viewProduct";// view name
	}

	@RequestMapping(value = "/listSellers", method = RequestMethod.GET)
	public String listSellers(Model model,HttpSession ses) {
		System.out.println("list seller");

		model.addAttribute("listProducts", 
				this.productService.listProducts());
		System.out.println("after return");
		return "viewSeller";// view name
	}
	
	@RequestMapping("/remove/{product_id}")
	
	public String delProduct(@PathVariable("product_id") int product_id)  {
		
			productService.delete(product_id);;
		
		return "sellerdashboard1";
	}



	@RequestMapping(value = "/admin/product/editProduct/{product_id}")
	public ModelAndView getEditForm(@PathVariable(value = "product_id") Integer product_id) {
		Product product = productService.get(product_id);
		System.out.println("ghhh");
		return new ModelAndView("viewProduct1", "editProductObj", product);
	}

	
	@RequestMapping(value = "/trying",method = RequestMethod.POST)
	public String trying(@ModelAttribute("editProductObj") Product p,BindingResult r) {
		System.out.println(r.toString());
		System.out.println(p);
		System.out.println("in update");
		productService.update(p);
		System.out.println("after update");
		return "sellerdashboard1";
		
	}
	






}





