
  package com.lti.shopping.DAO;
  
  import java.util.List;

import org.springframework.stereotype.Repository;


import com.lti.shopping.model.Seller;
@Repository
  public interface SellerDAO {
  
  boolean verifySeller(String email, String password);
  
  void addSeller(Seller s);
  
  Seller getByEmail(String email);
  public List<Seller> listSellers();
  
  void removeSeller(int sellId);
  
  
  }
 