
  package com.lti.shopping.model;
  
  import java.io.Serializable;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Lob;

import javax.persistence.ManyToOne;
import javax.persistence.Table;
  


  @Entity 
  @Table(name="Product")
  public class Product implements Serializable{
  
	  private static final long serialVersionUID = 1L;
	  
	  @Id
	  @GeneratedValue(strategy = GenerationType.AUTO)
	  private Integer product_id;
	  
	
	  
	  @ManyToOne(cascade=CascadeType.ALL)
	 Seller seller;
	  private String productName;
	  private String pdescription;
	  private int quantity;
	  private int price;
	  private byte[] image;
	  
	  public Seller getSeller() {
		return seller;
	}
	public void setSeller(Seller seller) {
		this.seller = seller;
	}


	  String category;

		
 
	  public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}

	
	
	public Integer getProduct_id() {
	return product_id;
}
public void setProduct_id(Integer product_id) {
	this.product_id = product_id;
}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPdescription() {
		return pdescription;
	}
	public void setPdescription(String pdescription) {
		this.pdescription = pdescription;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Lob
    @Column(name = "Image", length = Integer.MAX_VALUE, nullable = true)
public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	
	public Product() {
		super();
	}
//	@Override
//	public String toString() {
//		return "Product [product_id=" + product_id + ", sellerList=" + sellerList + ", category=" + category
//				+ ", productName=" + productName + ", pdescription=" + pdescription + ", quantity=" + quantity
//				+ ", price=" + price + "]";
//	}
	  
	  
	  
	  
	  
  }
 